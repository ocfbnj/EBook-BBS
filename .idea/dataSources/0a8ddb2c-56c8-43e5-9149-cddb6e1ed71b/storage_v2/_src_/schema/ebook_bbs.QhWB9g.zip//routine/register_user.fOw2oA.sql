create
    definer = root@`%` procedure register_user(IN username_ varchar(18), IN password_ varchar(20), IN name_ varchar(8),
                                               IN sex_ enum ('M', 'F'), IN age_ tinyint, IN phone_ char(11),
                                               IN email_ varchar(20))
begin
    insert into user (username, password, name, sex, age, phone, email, create_time)
    values (username_, password_, name_, sex_, age_, phone_, email_, now());
end;

