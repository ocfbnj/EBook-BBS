create
    definer = root@localhost procedure add_comment(IN parent_comment_id_ int, IN content_ text, IN user_id_ int,
                                                   IN ebook_id_ int)
begin
    insert into comment (parent_comment_id, content, user_id, ebook_id, date)
    values (parent_comment_id_, content_, user_id_, ebook_id_, now());
end;

