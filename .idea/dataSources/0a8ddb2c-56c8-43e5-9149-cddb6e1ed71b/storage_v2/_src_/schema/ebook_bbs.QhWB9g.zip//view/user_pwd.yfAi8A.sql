create definer = root@`%` view user_pwd as
select `ebook_bbs`.`user`.`user_id` AS `user_id`, `ebook_bbs`.`user`.`password` AS `password`
from `ebook_bbs`.`user`;

