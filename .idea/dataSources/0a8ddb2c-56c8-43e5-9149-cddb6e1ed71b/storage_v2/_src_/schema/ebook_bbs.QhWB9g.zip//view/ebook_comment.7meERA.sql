create view ebook_comment as
select `ebook_bbs`.`comment`.`ebook_id`          AS `ebook_id`,
       `ebook_bbs`.`comment`.`comment_id`        AS `comment_id`,
       `ebook_bbs`.`comment`.`content`           AS `content`,
       `ebook_bbs`.`comment`.`parent_comment_id` AS `parent_comment_id`,
       `ebook_bbs`.`comment`.`user_id`           AS `user_id`,
       `ebook_bbs`.`comment`.`date`              AS `date`,
       `ebook_bbs`.`user`.`username`             AS `username`
from (`ebook_bbs`.`user`
         join `ebook_bbs`.`comment` on ((`ebook_bbs`.`user`.`user_id` = `ebook_bbs`.`comment`.`user_id`)))
order by `ebook_bbs`.`comment`.`date` desc;

