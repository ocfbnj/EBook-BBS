create
    definer = root@localhost procedure add_like(IN user_id_ int, IN ebook_id_ int, IN common_id_ int)
begin

end;

